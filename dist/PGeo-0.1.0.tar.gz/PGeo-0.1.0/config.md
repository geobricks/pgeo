# python modules to install

# TODO we should ge tthe right version currently used
sudo apt-get install python-flask
pip install flask-cors
pymongo
osgeo
psycopg2
python-epydoc


probably:
numpy
scipy 
pysal (that has a dependency with scipy)
