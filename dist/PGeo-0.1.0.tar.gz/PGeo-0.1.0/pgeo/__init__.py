__package__ = 'pgeo'
__author__ = 'Barbaglia, Guido - Murzilli, Simone'
__email__ = 'guido.barbaglia@gmail.com; simone.murzilli@gmail.com;'
__license__ = 'GPL2'